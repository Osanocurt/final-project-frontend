angular.module('finalProject')
.directive('map', map);
function map() {

  return {

    restrict: 'A',
    scope: {
      options: '=map',
      url: 'map.html'
    },
    link: function link(scope, element) {
      new google.maps.Map(element[0], scope.options);
    }

  };
}
